import im from '../assert/kl.png'

const Experiment1 = ({s1, s2}) => {
    return (
    <div style = {s1}>
      <div style = {s2}>
      <img src = {im} alt = "kl logo" width = '200' />
      </div>
      <p> Balajee R M </p>
      <p> A.P - CSE </p>
    </div>
  )
}

export default Experiment1