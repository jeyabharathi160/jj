const Notification = (props) => {
	return (
		<div>
			{props.message}
		</div>
	)
}

export default Notification